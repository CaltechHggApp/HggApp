// file taken from SpartyJet v2.20.0

#include "CommonUtils.hh"
#include <list>

#include <fastjet/internal/base.hh>

FASTJET_BEGIN_NAMESPACE

namespace atlas { 

// void clear_list(Jet::jet_list_t &list, Jet::jet_list_t::iterator jit, Jet::jet_list_t::iterator jitE ){
//   Jet::jet_list_t::iterator jittmp = jit;
//   for(; jit != jitE; ++jit){
//     delete *jit;
//   }
//   list.erase(jittmp,jitE);
// }

}  // namespace atlas

FASTJET_END_NAMESPACE

