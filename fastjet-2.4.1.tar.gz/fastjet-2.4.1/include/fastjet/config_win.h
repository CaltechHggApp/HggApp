#define PACKAGE_STRING  "FastJet 2.4.1"
#define PACKAGE_VERSION  "2.4.1"

/* The CDFJetClu and CDFMidPoint plugins are enabled by default*/
#define ENABLE_PLUGIN_CDFCONES 

/* The PxCone plugin is disabled by default*/
#undef ENABLE_PLUGIN_PXCONE

/* The SISCone plugin is enabled by default*/
#define ENABLE_PLUGIN_SISCONE 
